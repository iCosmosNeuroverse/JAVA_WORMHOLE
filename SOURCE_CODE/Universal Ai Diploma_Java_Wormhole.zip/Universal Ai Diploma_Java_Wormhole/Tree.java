//Author: God Bennett
//Universal Ai Diploma
//Java_Wormhole - Reasonably rapid movement from 0 java practice to absorption of Java Programming, for the purpose of Universal Ai Diploma

/////////////////OVERVIEW
//1. Describe planet tree blueprint


//////////////////////////
//TREE BLUEPRINT
//////////////////////////

public class Tree
{
    //features
    private String colour;
    
    //Constructor
    //Tells us how to put a tree on a planet or in Main Reality, by describing a colour.
    public Tree ( String colour )
    {
        this.colour = colour; 
    }
    
    
    
    public String getColour ( )
    {
        return colour;
    }
}